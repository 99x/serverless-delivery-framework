module.exports.redirect = function(event, context) {
    if (event.headers.Authorization == undefined && event.query.user == undefined) {

        context.fail(("https://s3.amazonaws.com/serverless-delivery-framework/index.html"));


    } else {
        context.fail(("https://s3.amazonaws.com/serverless-delivery-framework/index.html"));
    }
};
